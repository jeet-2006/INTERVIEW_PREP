package com.e_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
